<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \DateTimeInterface;

class SubscriptionPackage extends Model
{
    use SoftDeletes;

    public $table = 'subscription_packages';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'description',
        'price',
        'duration',
        'number_branches',
        'percentage_of_sales',
        'created_at',
        'updated_at',
        'deleted_at',
        'referral_price',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
