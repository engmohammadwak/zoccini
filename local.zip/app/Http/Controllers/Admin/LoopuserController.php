<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyLoopuserRequest;
use App\Http\Requests\StoreLoopuserRequest;
use App\Http\Requests\UpdateLoopuserRequest;
use App\Models\City;
use App\Models\Country;
use App\Models\Loopuser;
use App\Models\User;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class LoopuserController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('loopuser_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $loopusers = Loopuser::with(['country', 'city', 'user'])->get();

        return view('admin.loopusers.index', compact('loopusers'));
    }

    public function create()
    {
        abort_if(Gate::denies('loopuser_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $countries = Country::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $cities = City::all()->pluck('name_ar', 'id')->prepend(trans('global.pleaseSelect'), '');

        $users = User::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.loopusers.create', compact('countries', 'cities', 'users'));
    }

    public function store(StoreLoopuserRequest $request)
    {
        $loopuser = Loopuser::create($request->all());

        return redirect()->route('admin.loopusers.index');
    }

    public function edit(Loopuser $loopuser)
    {
        abort_if(Gate::denies('loopuser_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $countries = Country::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $cities = City::all()->pluck('name_ar', 'id')->prepend(trans('global.pleaseSelect'), '');

        $users = User::all()->pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $loopuser->load('country', 'city', 'user');

        return view('admin.loopusers.edit', compact('countries', 'cities', 'users', 'loopuser'));
    }

    public function update(UpdateLoopuserRequest $request, Loopuser $loopuser)
    {
        $loopuser->update($request->all());

        return redirect()->route('admin.loopusers.index');
    }

    public function show(Loopuser $loopuser)
    {
        abort_if(Gate::denies('loopuser_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $loopuser->load('country', 'city', 'user');

        return view('admin.loopusers.show', compact('loopuser'));
    }

    public function destroy(Loopuser $loopuser)
    {
        abort_if(Gate::denies('loopuser_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $loopuser->delete();

        return back();
    }

    public function massDestroy(MassDestroyLoopuserRequest $request)
    {
        Loopuser::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
