<?php

namespace App\Http\Controllers;

use App\Models\BecomePartner;
use App\Models\CategoryTopRestaurant;
use App\Models\City;
use App\Models\Image;
use App\Models\Loopuser;
use App\Models\ReferralSubscription;
use App\Models\Restaurant;
use App\Models\Slider;
use App\Models\SubscriptionPackage;
use App\Models\TopRestaurant;
use App\Models\User;
use App\Models\VentureCompany;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
//    public function __construct()
//    {
//        $this->middleware('auth');
//    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $top_restaurant = TopRestaurant::all();
        $slider = Slider::all();
        $slider_count = Slider::count();
        $categories = CategoryTopRestaurant::all();
        $venture_company = VentureCompany::all();

        return view('welcome', compact('top_restaurant', 'slider', 'slider_count', 'categories', 'venture_company'));

    }

    public function map(Request $request)
    {
        $restaurant = Restaurant::where('lat' , '!=' , null)->where('lang' , '!=' , null)->take(5);
        if ($request->key)
        {
            $restaurant =   $restaurant->where('name_ar' , 'like' , '%'.$request->key.'%')->orWhere('name_en' , 'like' , '%'.$request->key.'%');
        }

        if ($request->city_id)
        {
            $restaurant =   $restaurant->where('city_id' , $request->city_id);
        }

        $restaurant =  $restaurant->get();
        $city = City::where('status' , 1)->get();
        return view('map', compact('restaurant' , 'city'));

    }

    public function become_partner()
    {
        $become_partner = BecomePartner::all();

        return view('become_partner', compact('become_partner'));

    }

    public function become_partner_store(Request $request)
    {
        $user = new User();
        $user->name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->phone = $request->country_code .$request->phone;
        $user->email = $request->email;
        $user->password = Hash::make('123456');
        $user->user_type = 3;
        $user->status_id = 4;
        $user->save();
        $user->roles()->sync(3);
        if ($request->file('logo')) {
            $image = uploadImage($request->file('logo'),'/public/img/user' , $user->image);
            $user->fill(['image' => $image])->save();
        }

        if ($request->file('commercial_registration_image')) {
            $image = uploadImage($request->file('commercial_registration_image'),'/public/img/user' , $user->image);
            $user->fill(['commercial_registration_image' => $image])->save();
        }

        $request->request->add(['restaurant_id' => $user->id]);
        $request->request->add(['name_en' => $request->name_ar  , 'plan_id' => $request->id  ]);
        if (Auth::check()){
            $request->request->add(['referral_id' => Auth::id()]);
        }
        $request->request->add(['name_en' => $request->name_ar  , 'plan_id' => $request->id  ]);

        $restaurant = Restaurant::create($request->all());
        $restaurant->payment_methods()->sync($request->input('payment_methods', []));
        $restaurant->sitting_areas()->sync($request->input('sitting_areas', []));

        if ($request->file('image')) {
            $image = uploadImage($request->file('image'),'/public/img/'.Restaurant::DIR_UPLOAD , $restaurant->image);
            $restaurant->fill(['image' => $image])->save();
        }
        if ($request->file('photo')) {
            foreach ($request->file('photo') as $file) {
                $photo_name = uploadImage($file,'/public/img/'.Image::DIR_UPLOAD );

                Image::create([
                    'name' => $photo_name,
                    'model' => Image::COMPANY_MODEL,
                    'item' => $restaurant->id,
                ]);
            }
        }

        if (Auth::check()){
            $request->request->add(['referral_id' => Auth::id()]);

            $plan = SubscriptionPackage::find($request->id);
            if ($plan)
            {
                $referral_price = $plan->referral_price;
            }else{
                $referral_price = 0;
            }
            ReferralSubscription::create([
                'user_id' => $restaurant->id,
                'user_loop_id' => Auth::id(),
                'plan_id' => $request->id,
                'price' => $referral_price,
            ]);
        }

        return view('success');
    }

    public function join_loop_post(Request $request)
    {

        $user = new User();
        $user->name = $request->name;
        $user->last_name = $request->last_name;
        $user->phone = $request->country_code .$request->phone;
        $user->email = $request->email;
        $user->password = Hash::make('123456');
        $user->user_type = 12;
        $user->status_id = 1;
        $user->save();
        $user->roles()->sync([12]);

        $request->request->add(['user_id' => $user->id]);

        $loop = Loopuser::create($request->all());

        if ($request->file('attach_national')) {
            $image = uploadImage($request->file('attach_national'),'/public/img/user');
            $loop->fill(['attach_national' => $image])->save();
        }

        if ($request->file('invoice_image')) {
            $image = uploadImage($request->file('invoice_image'),'/public/img/user');
            $loop->fill(['invoice_image' => $image])->save();
        }

        return view('success');
    }

    public function update_profile(Request $request)
    {
        $user = User::find(Auth::id());
        $user->update($request->all());

        $loop = Loopuser::where('user_id' , \Illuminate\Support\Facades\Auth::id())->first();
        $loop->update($request->all());

        if ($request->file('attach_national')) {
            $image = uploadImage($request->file('attach_national'),'/public/img/user');
            $loop->fill(['attach_national' => $image])->save();
        }
        return view('success');
    }
}
