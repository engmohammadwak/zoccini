<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\App;

class ItemResource extends JsonResource
{
    public function toArray($request)
    {
        $image = url('local/public/img/item/' . $this->photo);
        if ( App::getLocale() == 'ar') {
            $name        = $this->name_ar;
            $description = $this->description_ar;
        }else {
            $name        = $this->name_en;
            $description = $this->description_en;
        }

        return [
            'id' => $this->id,
            'name' => $name,
            'price' => (double) $this->price,
            'description' => $description,
            'photo' => $image,
            'isFavority' => isFavority($this->id , 1),
            'extra' => ExtraResource::collection($this->extra),
        ];
    }
}
