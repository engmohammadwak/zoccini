(function ($) {
    "use-strict";

    /*------------------------------------
          menu mobile
      --------------------------------------*/
    $(".header-mobile__toolbar").on("click", function () {
        $(".menu--mobile").addClass("menu-mobile-active");
        $(".mobile-menu-overlay").addClass("mobile-menu-overlay-active");
    });

    $(".mobile-menu-overlay").on("click", function () {
        $(".menu--mobile").removeClass("menu-mobile-active");
        $(".mobile-menu-overlay").removeClass("mobile-menu-overlay-active");
    });

    $(".main-header .btn-close-header-mobile").on("click", function () {
        $(".menu--mobile").removeClass("menu-mobile-active");
        $(".mobile-menu-overlay").removeClass("mobile-menu-overlay-active");
    });

    /*------------------------------------
          loader page
      --------------------------------------*/
    $(window).on("load", function () {
        $(".loader-page").fadeOut(500);
        var wow = new WOW({
            boxClass: "wow",
            animateClass: "animated",
            offset: 0,
            mobile: false,
            live: true,
        });
        new WOW().init();
    });

    /*------------------------------------
          selectpicker
      --------------------------------------*/

    var form = $(".form-login");
    form.validate({
        highlight: function (element) {
            $(element).closest(".form-group").addClass("error");
        },
        unhighlight: function (element) {
            $(element).closest(".form-group").removeClass("error");
        },
        errorPlacement: function errorPlacement(error, element) {
            element.before(error);
            // if(error){
            //   $('.form-control.error').closest('.form-group').addClass('s')
            // }else{
            //   $('.form-control.error').closest('.form-group').removeClass('s')
            // }
        },

        rules: {
            userName: {
                required: true,
            },
            lastName: {
                required: true,
            },
            email: {
                required: true,
                email: true,
            },
            phone: {
                required: true,
                number: true,
            },
            restaurantName: {
                required: true,
            },
            address: {
                required: true,
            },
            companyEmail: {
                required: true,
                email: true,
            },
            phone_2: {
                required: true,
                number: true,
            },
            restaurantLogo: {
                required: true,
            },
            restaurantLicence: {
                required: true,
            },
            radio: {
                required: true,
            },
            branchName: {
                required: true,
            },
            branchAddress: {
                required: true,
            },
            branchMobile: {
                required: true,
                number: true,
            },
        },
        messages: {
            userName: {
                required: "This field is required.",
            },
            lastName: {
                required: "This field is required.",
            },
            email: {
                required: "This field is required.",
                email: "Please enter a valid email address.",
            },
            employeeNo: {
                required: "This field is required.",
                number: "Please enter a valid number",
            },
            restaurantName: {
                required: "This field is required.",
            },
            branchMobile: {
                required: "This field is required.",
                number: "Please enter a valid number",
            },
        },
    });

    let isChecked = true;

    form.steps({
        // saveState: true,
        headerTag: "h3",
        labels: {
            next: "Next",
            finish: "Next",
            current: "Next",
            previous: "Back",
        },
        bodyTag: "section",
        transitionEffect: "slideLeft",
        onStepChanging: function (event, previousIndex, newIndex, currentIndex) {
            if (isChecked)
                $("#steps-uid-0-p-2 .step-content").attr("style", "display: block !important");
            $("#steps-uid-0-p-2 .step-content").removeClass("step3");

            // if(previousIndex == 2 && newIndex === 3 && isChecked)
            //   return true;

            if (previousIndex > newIndex) return true;

            form.validate().settings.ignore = ":disabled,:hidden";
            return form.valid();
        },
        onStepChanged: function (event, newIndex, previousIndex) {
            if (newIndex === 0) {
                $(".actions ul li:first-child").fadeOut(1);
            }
            if (newIndex === 1) {
                $(".actions ul li:first-child").fadeIn(1);
            }
            if (newIndex === 2) {
                $(".actions ul li:first-child").fadeIn(1);
                $('.wizard > .actions > ul > li:nth-of-type(1)').click(function () {
                    $("#steps-uid-0-p-2 .step-content").attr("style", "display: none !important");
                    $("#steps-uid-0-p-2 .step-content").removeClass("step3");
                    $("#steps-uid-0-p-2 input").prop("disabled", true);
                })
            }

            if (newIndex === 3) {
                $(".actions ul li:first-child").fadeIn(1);
            }
            // if (currentIndex == 2) {
            //   $('.wizard > .actions > ul > li:nth-of-type(2)').click(function(){
            //     $("#steps-uid-0-p-2 .step-content").addClass("step33");
            //   })
            // }

            // if (previousIndex === 0 && newIndex === 1) {
            //   $('.actions ul li:first-child').fadeIn(1);
            // }
            if (previousIndex === 1 && newIndex === 2) {
                if (isChecked) form.steps("next", 3);

                isChecked = true;
            }

            if (previousIndex === 3 && newIndex === 2) form.steps("previous", 1);
        },
        onFinishing: function (event, currentIndex) {
            form.validate().settings.ignore = ":disabled";
            return form.valid();
        },
        onFinished: function (event, currentIndex) {
            // alert("Submitted!");
            document.getElementById("my_form").submit();

        },
    });
    $(".goStepBransh").click(function () {
        isChecked = false;
        form.steps("next", 2);
        $("#steps-uid-0-p-2 input").prop("disabled", false);
        $("#steps-uid-0-p-2 .step-content").attr("style", "display: block !important").addClass("step3");
    });

    $(".wizard > .actions > ul li:nth-of-type(1)").click(function () {
        $("#steps-uid-0-p-2 .step-content").attr("style", "display: none !important");
        $("#steps-uid-0-p-2 .step-content").removeClass("step3");
    });

    $(".wizard > .actions > ul li:nth-of-type(2)").click(function () {
        $("#steps-uid-0-p-2 .step-content").attr("style", "display: none !important");
        $("#steps-uid-0-p-2 .step-content").removeClass("step3");
        if ($(".branch-name").val() == "" || $(".branch-address").val() == "" || $(".branch-mobile").val() == "") {
            $("#steps-uid-0-p-2 .step-content").attr("style", "display: block !important");
            $("#steps-uid-0-p-2 .step-content.step3").removeClass("step3");
        } else {
            $("#steps-uid-0-p-2 .step-content").attr("style", "display: none !important");
            $("#steps-uid-0-p-2 .step-content").removeClass("step3");
        }
        isChecked = true;
    });

    $(".actions ul li:first-child a").html(`
      <svg class="mr-1" width="6" height="9" viewBox="0 0 6 9" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M2.03659 4.5019L5.77756 1.13488C5.88057 1.04239 5.93724 0.918732 5.93724 0.786878C5.93724 0.654951 5.88057 0.531366 5.77756 0.438732L5.44976 0.143854C5.34691 0.0510732 5.20943 0 5.06293 0C4.91642 0 4.77911 0.0510732 4.67618 0.143854L0.221953 4.15259C0.11862 4.24551 0.0620346 4.36968 0.0624411 4.50168C0.0620346 4.63427 0.118539 4.75829 0.221953 4.85129L4.67203 8.85615C4.77496 8.94893 4.91228 9 5.05886 9C5.20537 9 5.34268 8.94893 5.44569 8.85615L5.77342 8.56127C5.98667 8.36934 5.98667 8.0569 5.77342 7.86505L2.03659 4.5019Z" fill="black"></path>
      </svg>
    <span>Back</span>`);


    $(".selectpicker").selectpicker();

    //
    $(".uploadeImage").change(function () {
        $(this).closest(".form-group").find(".name-image").text(this.files[0].name);
        $(this).closest(".form-group").removeClass("error");
        $(this).closest(".form-group").find("label.error").remove();
    });

    /*------------------------------------
          Add Branch On click
      --------------------------------------*/
    $(document).on("click", ".add-branch", function () {
        if ($(".widget-item-branch").length > 0 || $(".widget-item-branch").length == 0) {
            $(".widget-list-add-branch").fadeIn();
            animateLable();
        }
    });

    /*------------------------------------
          Add Item Branch On click
      --------------------------------------*/
    $(document).on("click", ".add-item-branch", function () {
        var $branchName = $(".branch-name").val();
        var $brancAddress = $(".branch-address").val();
        var $brancMobile = $(".branch-mobile").val();
        var $brancState = $(".branch-state").find(".filter-option-inner-inner .number").text();
        if ($(".branch-name").val() == "" || $(".branch-address").val() == "" || $(".branch-mobile").val() == "") {
            $(".widget-add-branch .required").remove();
            $(".widget-add-branch").append(`<span class="text-danger required ml-2">This All field is required.</span>`);
        } else {
            $(".widget-add-branch .required").remove();
            $(".widget-list-items-branch").append(`
          <div class="widget-item-branch py-3 px-4 mb-2">
            <div class="d-flex align-items-start justify-content-between">
              <h5 class="widget-item-name">${$branchName}</h5>
              <button class="text-danger font-medium bg-white delete-item-branch" type="button">Delete</button>
            </div>
            <p class="widget-item-addres">${$brancAddress}</p>
            <p class="widget-item-mobile">${$brancState} ${$brancMobile}</p>
          </div>
        `);
            $(".widget-list-add-branch").fadeOut(70);
            $(".widget-list-items-branch .widget-item-branch").last().hide().fadeIn(800);
            var $branchName = $(".branch-name").val("");
            var $brancAddress = $(".branch-address").val("");
            var $brancMobile = $(".branch-mobile").val("");
            if ($(".widget-item-branch").length > 1) {
                var height = $(".step-four .content-step").height();
                $(".wrapper-step").css("height", height);
            }
        }
    });

    /*------------------------------------
          Remove Item Branch On click
      --------------------------------------*/
    $(document).on("click", ".delete-item-branch", function () {
        $(this)
            .closest(".widget-item-branch")
            .fadeOut(300, function () {
                $(this).remove();
            });
    });
    //

    animateLable();

    $("#cascade-slider").cascadeSlider({});
})(jQuery);

/*------------------------------------
Action Placeholder Input
--------------------------------------*/
function animateLable() {
    var $form = $(".form-login"),
        $elements = $form.find('input[type="text"],textarea, select');

    $elements.each(function (index, element) {
        refreshValueState(element);

        $(element).focus(function () {
            $(element).parent().addClass("has-value");
        });
    });

    $elements.on("blur", function (e) {
        var element = e.currentTarget;

        refreshValueState(element);
    });
}

function refreshValueState(element) {
    var cleanedValue = $(element).val().replace(/^\s+$/, "");

    $(element).val(cleanedValue);

    if ($(element).val() !== "") {
        $(element).parent().addClass("has-value");
    } else {
        $(element).parent().removeClass("has-value");
    }
}

/*------------------------------------
  swiper
--------------------------------------*/

var slider_phone = new Swiper(".slider-phone", {
    slidesPerView: 3,
    centeredSlides: true,
    loop: true,
    speed: 2000,
    // autoplay: {
    //   delay: 4000,
    //   disableOnInteraction: false
    // },
    // pagination: {
    //   el: '.swiper-pagination',
    //   clickable: true,
    // },
    navigation: {
        nextEl: ".action-swiper .swiper-button-next",
        prevEl: ".action-swiper .swiper-button-prev",
    },
});

var slider_clients = new Swiper(".slider-clients", {
    slidesPerView: 6,
    loop: false,
    speed: 2000,
    slidesPerColumn: 3,
    slidesPerGroup: 6,
    spaceBetween: 30,
    // autoplay: {
    //   delay: 4000,
    //   disableOnInteraction: false,
    // },
    pagination: {
        el: "#section-partners .swiper-pagination",
        clickable: true,
    },
    // navigation: {
    //   nextEl: '.action-swiper .swiper-button-next',
    //   prevEl: '.action-swiper .swiper-button-prev',
    // },
    breakpoints: {
        576: {
            slidesPerView: 2,
        },
        768: {
            slidesPerView: 2,
        },
        992: {
            slidesPerView: 3,
        },
        1400: {
            slidesPerView: 6,
        },
    },
});

$(".swiper-filter").on("click", ".btn-filter", function () {
    var filter = $(this).attr("data-filter");
    $(".slider-rest .swiper-slide").fadeOut(0);
    $(".slider-rest .swiper-slide" + filter).fadeIn();
    $(".swiper-filter .btn-filter").removeClass("swiper-active");
    $(this).addClass("swiper-active");

    slider_rest.updateSize();
    slider_rest.updateSlides();
    slider_rest.updateProgress();
    slider_rest.updateSlidesClasses();
    slider_rest.slideTo(0);
    slider_rest.scrollbar.updateSize();

    return false;
});

var filterSwiper = new Swiper(".swiper-filter", {
    slidesPerView: "auto",
    spaceBetween: 40,
});

var slider_rest = new Swiper(".slider-rest", {
    slidesPerView: 3,
    loop: false,
    speed: 2000,
    spaceBetween: 30,
    scrollbarHide: false,
    updateOnImagesReady: true,
    observer: true,
    runCallbacksOnInit: true,
    // autoplay: {
    //   delay: 4000,
    //   disableOnInteraction: false
    // },
    pagination: {
        el: "#section-restaurants .swiper-pagination",
        clickable: true,
    },
    // navigation: {
    //   nextEl: '.action-swiper .swiper-button-next',
    //   prevEl: '.action-swiper .swiper-button-prev',
    // },
    breakpoints: {
        576: {
            slidesPerView: 1.2,
        },
        768: {
            slidesPerView: 1.5,
        },
        992: {
            slidesPerView: 2.5,
        },
        1400: {
            slidesPerView: 3,
        },
    },
});
